package com.example;

public class Xis4 extends Lanche {

    public Xis4() {
        super("Xis Frango", 27);

    }
    
}
