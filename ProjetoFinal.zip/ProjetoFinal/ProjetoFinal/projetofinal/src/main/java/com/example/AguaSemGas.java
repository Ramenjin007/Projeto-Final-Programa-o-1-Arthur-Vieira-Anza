package com.example;

public class AguaSemGas extends Lanche {

    public AguaSemGas() {
        super("Água sem Gás 500ml", 5);
    }
    
}
