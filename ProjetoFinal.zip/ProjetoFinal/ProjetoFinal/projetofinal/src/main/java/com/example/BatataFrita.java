package com.example;

public class BatataFrita extends Lanche{

    public BatataFrita() {
    super("Batata Frita", 10);
   
    }
        
}
