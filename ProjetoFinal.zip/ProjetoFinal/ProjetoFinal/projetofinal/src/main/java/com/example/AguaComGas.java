package com.example;

public class AguaComGas extends Lanche {

    public AguaComGas() {
        super("Água com Gás 500ml", 5);
        
    }
    
}
