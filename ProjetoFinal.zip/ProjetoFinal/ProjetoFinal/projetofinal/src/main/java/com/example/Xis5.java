package com.example;

public class Xis5 extends Lanche {

    public Xis5() {
        super("Xis Calabresa", 27);
    }
    
}
