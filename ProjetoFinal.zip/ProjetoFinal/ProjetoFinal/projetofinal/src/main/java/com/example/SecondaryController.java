package com.example;

import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import java.util.ArrayList;

public class SecondaryController {

    @FXML private TextArea txPedidos;

    public void receberPedido(Pedido p) {
        txPedidos.appendText("Novo pedido recebido:\n");
        txPedidos.appendText(p.toString() + "\n");
    }

    public void atualizarPedido(Pedido pedido) {
        if (pedido == null) return;

        StringBuilder sb = new StringBuilder();

        sb.append("ITENS DO PEDIDO:\n\n");

        ArrayList<Lanche> itens = pedido.getItens();

        for (int i = 0; i < itens.size(); i++) {
            Lanche l = itens.get(i);
            sb.append((i+1) + ") " + l.getNome() + " — R$ " + l.getPreço() + "\n");
        }

        sb.append("\nTOTAL: R$ ").append(pedido.getTotal()).append("\n");

        txPedidos.setText(sb.toString());
    }

    @FXML
    private void concluirPedido() {
        txPedidos.appendText("\n*** PEDIDO CONCLUÍDO ***\n\n");
    }
}