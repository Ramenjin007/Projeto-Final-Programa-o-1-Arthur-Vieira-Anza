package com.example;

public class Refri extends Lanche {

    public Refri() {
        super("Coca-Cola", 8);
    }
    
    
}
