package com.example;

public class Xis1 extends Lanche {

    public Xis1() {
        super("Xis da Chapa", 23);
    }
    
}
