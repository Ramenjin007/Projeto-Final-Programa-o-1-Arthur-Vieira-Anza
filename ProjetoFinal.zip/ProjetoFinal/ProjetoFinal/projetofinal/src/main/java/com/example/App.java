package com.example;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class App extends Application {

    @Override
    public void start(Stage stage1) throws Exception {


        FXMLLoader primaryLoader = new FXMLLoader(getClass().getResource("primary.fxml"));
        Scene scene1 = new Scene(primaryLoader.load(), 640, 480);


        PrimaryController primaryController = primaryLoader.getController();

        stage1.setTitle("Terminal do Atendente");
        stage1.setScene(scene1);
        stage1.show();



        FXMLLoader secondaryLoader = new FXMLLoader(getClass().getResource("secondary.fxml"));
        Scene scene2 = new Scene(secondaryLoader.load(), 500, 400);


        SecondaryController secondaryController = secondaryLoader.getController();

        Stage stage2 = new Stage();
        stage2.setTitle("Tela da Cozinha");
        stage2.setScene(scene2);
        stage2.show();



        primaryController.setReceiverController(secondaryController);
    }

    public static void main(String[] args) {
        launch();
    }
}