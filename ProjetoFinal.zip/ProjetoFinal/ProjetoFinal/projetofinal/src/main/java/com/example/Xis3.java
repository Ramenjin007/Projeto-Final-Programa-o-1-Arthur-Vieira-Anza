package com.example;

public class Xis3 extends Lanche {

    public Xis3() {
        super("Xis Coraçao", 30);
    }
    
}
