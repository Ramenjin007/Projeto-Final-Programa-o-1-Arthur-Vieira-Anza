package com.example;

import java.util.ArrayList;

public class Pedido {

    private ArrayList<Lanche> itens = new ArrayList<>();

    public void adicionarItem(Lanche l) {
        itens.add(l);
    }

    public ArrayList<Lanche> getItens() {
        return itens;
    }

    public int getTotal() {
        int soma = 0;
        for (Lanche l : itens) soma += l.getPreço();
        return soma;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Lanche l : itens) {
            sb.append(l.getNome()).append(" - ").append("R$ ").append(l.getPreço()).append("\n");
        }
        sb.append("Total: ").append(getTotal()).append(" R$\n");
        return sb.toString();
    }
}