package com.example;

import java.util.ArrayList;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class PrimaryController {

    @FXML private Button btProduto1;
    @FXML private Button btProduto2;
    @FXML private Button btProduto3;
    @FXML private Button btProduto4;
    @FXML private Button btProduto5;
    @FXML private Button btProduto6;
    @FXML private Button btProduto7;
    @FXML private Button btProduto8;
    @FXML private Button btProduto9;
    @FXML private Button btRemoveUltimo;
    @FXML private Button btFinalizaPedido;

    @FXML private Label lProduto1;
    @FXML private Label lProduto2;
    @FXML private Label lProduto3;
    @FXML private Label lProduto4;
    @FXML private Label lProduto5;
    @FXML private Label lProduto6;
    @FXML private Label lProduto7;
    @FXML private Label lProduto8;
    @FXML private Label lProduto9;
    @FXML private Label lProduto10;
    @FXML private Label lProduto11;
    @FXML private Label lProduto12;
    @FXML private Label lValorFinal;

    private Pedido pedidoAtual;
    private SecondaryController receiver;

    @FXML
    public void initialize() {
        pedidoAtual = new Pedido();
    }

    public void setReceiverController(SecondaryController sc) {
        this.receiver = sc;
    }

    private void adicionarProduto(Lanche lanche) {
        pedidoAtual.adicionarItem(lanche);
        atualizarResumo();
    }

    @FXML private void btProduto1Action() { adicionarProduto(new Xis1()); }
    @FXML private void btProduto2Action() { adicionarProduto(new Xis2()); } 
    @FXML private void btProduto3Action() { adicionarProduto(new Xis3()); } 
    @FXML private void btProduto4Action() { adicionarProduto(new Xis4()); }
    @FXML private void btProduto5Action() { adicionarProduto(new Xis5()); }
    @FXML private void btProduto6Action() { adicionarProduto(new BatataFrita()); }
    @FXML private void btProduto7Action() { adicionarProduto(new AguaSemGas()); }
    @FXML private void btProduto8Action() { adicionarProduto(new AguaComGas()); } 
    @FXML private void btProduto9Action() { adicionarProduto(new Refri()); }

    @FXML
    public void removerUltimoItem() {
        if (!pedidoAtual.getItens().isEmpty()) {
            pedidoAtual.getItens().remove(pedidoAtual.getItens().size() - 1);
            atualizarResumo();
        }
    }

    private void atualizarResumo() {

        ArrayList<Lanche> itens = pedidoAtual.getItens();

        Label[] labels = {
            lProduto1, lProduto2, lProduto3, lProduto4, lProduto5,
            lProduto6, lProduto7, lProduto8, lProduto9,
            lProduto10, lProduto11, lProduto12
        };

        for (int i = 0; i < labels.length; i++) {
            if (i < itens.size()) {
                labels[i].setText(itens.get(i).toString());
            } else {
                labels[i].setText("");
            }
        }

        lValorFinal.setText("Total: R$ " + pedidoAtual.getTotal());
    }

    @FXML
    private void finalizarPedido() {
        if (receiver != null) {
            receiver.receberPedido(pedidoAtual);
        }

        pedidoAtual = new Pedido();
        atualizarResumo();
    }
}