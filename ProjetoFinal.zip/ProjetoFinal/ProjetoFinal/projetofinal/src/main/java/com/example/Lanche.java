package com.example;

public abstract class  Lanche {

    String nome;
    int preço;
    public Lanche(String nome, int preço) {
        this.nome = nome;
        this.preço = preço;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public int getPreço() {
        return preço;
    }
    public void setPreço(int preço) {
        this.preço = preço;
    }

    @Override
    public String toString() {
        return nome + " - R$ " + preço;
    }
    
}
