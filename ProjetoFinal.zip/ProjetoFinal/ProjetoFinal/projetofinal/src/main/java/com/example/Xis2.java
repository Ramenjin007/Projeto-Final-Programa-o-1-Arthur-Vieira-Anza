package com.example;

public class Xis2 extends Lanche {

    public Xis2() {
        super("Xis Salada", 24);
    }
    
}
