package com.example;

public class ItemPedido {

    private Lanche lanche;

    public ItemPedido(Lanche lanche) {
        this.lanche = lanche;
    }

    public Lanche getLanche() {
        return lanche;
    }

    @Override
    public String toString() {
        return lanche.getNome() + " - R$ " + lanche.getPreço();
    }
}